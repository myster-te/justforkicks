"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.CopyObject = CopyObject;
exports.ValToString = ValToString;
exports.StringToVal = StringToVal;
exports.isJSONString = isJSONString;
var rx_one = /^[\],:{}\s]*$/;
var rx_two = /\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g;
var rx_three = /"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g;
var rx_four = /(?:^|:|,)(?:\s*\[)+/g;
var rx_dangerous = /[\u0000\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g;

function CopyObject(obj) {
  return JSON.parse(JSON.stringify(obj));
}

function ValToString(val) {
  var retval = undefined;

  switch (typeof val) {
    case "string":
      retval = val;
      break;

    case "boolean":
      retval = val.toString();
      break;

    case "number":
      retval = val.toString();
      break;

    case "object":
      if (val) retval = JSON.stringify(val);
      break;

    case "undefined":
      retval = "Undefined";
      break;
  }

  return retval ? retval : "undefined";
}

function StringToVal(valString) {
  var parsedobject;

  var setPO = PO => parsedobject = PO;

  return isJSONString(valString, setPO) ? parsedobject : !isNaN(valString) ? Number(valString) : valString === 'true' ? true : valString === 'false' ? false : valString;
}

function isJSONString(text, setParsedObject) {
  // The parse method takes a text and an optional reviver function, and returns
  // a JavaScript value if the text is a valid JSON text.
  // Parsing happens in four stages. In the first stage, we replace certain
  // Unicode characters with escape sequences. JavaScript handles many characters
  // incorrectly, either silently deleting them, or treating them as line endings.
  var j;
  text = String(text);
  rx_dangerous.lastIndex = 0;

  if (rx_dangerous.test(text)) {
    text = text.replace(rx_dangerous, function (a) {
      return "\\u" + ("0000" + a.charCodeAt(0).toString(16)).slice(-4);
    });
  } // In the second stage, we run the text against regular expressions that look
  // for non-JSON patterns. We are especially concerned with "()" and "new"
  // because they can cause invocation, and "=" because it can cause mutation.
  // But just to be safe, we want to reject all unexpected forms.
  // We split the second stage into 4 regexp operations in order to work around
  // crippling inefficiencies in IE's and Safari's regexp engines. First we
  // replace the JSON backslash pairs with "@" (a non-JSON character). Second, we
  // replace all simple value tokens with "]" characters. Third, we delete all
  // open brackets that follow a colon or comma or that begin the text. Finally,
  // we look to see that the remaining characters are only whitespace or "]" or
  // "," or ":" or "{" or "}". If that is so, then the text is safe for eval.


  if (rx_one.test(text.replace(rx_two, "@").replace(rx_three, "]").replace(rx_four, ""))) {
    // In the third stage we use the eval function to compile the text into a
    // JavaScript structure. The "{" operator is subject to a syntactic ambiguity
    // in JavaScript: it can begin a block or an object literal. We wrap the text
    // in parens to eliminate the ambiguity.
    j = eval("(" + text + ")"); // In the optional fourth stage, we recursively walk the new structure, passing
    // each name/value pair to a reviver function for possible transformation.

    setParsedObject(j);
    return true;
  } // If the text is not JSON parseable, then a SyntaxError is thrown.


  return false;
}

;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhlbHBlcnMudHMiXSwibmFtZXMiOlsicnhfb25lIiwicnhfdHdvIiwicnhfdGhyZWUiLCJyeF9mb3VyIiwicnhfZGFuZ2Vyb3VzIiwiQ29weU9iamVjdCIsIm9iaiIsIkpTT04iLCJwYXJzZSIsInN0cmluZ2lmeSIsIlZhbFRvU3RyaW5nIiwidmFsIiwicmV0dmFsIiwidW5kZWZpbmVkIiwidG9TdHJpbmciLCJTdHJpbmdUb1ZhbCIsInZhbFN0cmluZyIsInBhcnNlZG9iamVjdCIsInNldFBPIiwiUE8iLCJpc0pTT05TdHJpbmciLCJpc05hTiIsIk51bWJlciIsInRleHQiLCJzZXRQYXJzZWRPYmplY3QiLCJqIiwiU3RyaW5nIiwibGFzdEluZGV4IiwidGVzdCIsInJlcGxhY2UiLCJhIiwiY2hhckNvZGVBdCIsInNsaWNlIiwiZXZhbCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQUEsSUFBSUEsTUFBTSxHQUFHLGVBQWI7QUFDQSxJQUFJQyxNQUFNLEdBQUcscUNBQWI7QUFDQSxJQUFJQyxRQUFRLEdBQUcsa0VBQWY7QUFDQSxJQUFJQyxPQUFPLEdBQUcsc0JBQWQ7QUFDQSxJQUFJQyxZQUFZLEdBQUcsMEdBQW5COztBQUdPLFNBQVNDLFVBQVQsQ0FBb0JDLEdBQXBCLEVBQTRCO0FBQ2pDLFNBQU9DLElBQUksQ0FBQ0MsS0FBTCxDQUFXRCxJQUFJLENBQUNFLFNBQUwsQ0FBZUgsR0FBZixDQUFYLENBQVA7QUFDRDs7QUFHTSxTQUFTSSxXQUFULENBQXFCQyxHQUFyQixFQUFvQztBQUN6QyxNQUFJQyxNQUF1QixHQUFHQyxTQUE5Qjs7QUFDQSxVQUFRLE9BQU9GLEdBQWY7QUFDRSxTQUFLLFFBQUw7QUFDRUMsTUFBQUEsTUFBTSxHQUFDRCxHQUFQO0FBQ0E7O0FBQ0YsU0FBSyxTQUFMO0FBQ0VDLE1BQUFBLE1BQU0sR0FBRUQsR0FBRyxDQUFDRyxRQUFKLEVBQVI7QUFDQTs7QUFDRixTQUFLLFFBQUw7QUFDRUYsTUFBQUEsTUFBTSxHQUFFRCxHQUFHLENBQUNHLFFBQUosRUFBUjtBQUNBOztBQUNGLFNBQUssUUFBTDtBQUNFLFVBQUlILEdBQUosRUFDRUMsTUFBTSxHQUFDTCxJQUFJLENBQUNFLFNBQUwsQ0FBZUUsR0FBZixDQUFQO0FBQ0Y7O0FBQ0YsU0FBSyxXQUFMO0FBQ0VDLE1BQUFBLE1BQU0sR0FBQyxXQUFQO0FBQ0E7QUFoQko7O0FBa0JBLFNBQU9BLE1BQU0sR0FBQ0EsTUFBRCxHQUFRLFdBQXJCO0FBQ0Q7O0FBRU0sU0FBU0csV0FBVCxDQUFxQkMsU0FBckIsRUFBeUU7QUFDOUUsTUFBSUMsWUFBSjs7QUFDQSxNQUFJQyxLQUFLLEdBQUlDLEVBQUQsSUFBVUYsWUFBWSxHQUFDRSxFQUFuQzs7QUFDQSxTQUFPQyxZQUFZLENBQUNKLFNBQUQsRUFBV0UsS0FBWCxDQUFaLEdBQStCRCxZQUEvQixHQUNDLENBQUNJLEtBQUssQ0FBQ0wsU0FBRCxDQUFOLEdBQW1CTSxNQUFNLENBQUNOLFNBQUQsQ0FBekIsR0FDQUEsU0FBUyxLQUFLLE1BQWQsR0FBdUIsSUFBdkIsR0FDQUEsU0FBUyxLQUFLLE9BQWQsR0FBd0IsS0FBeEIsR0FDQUEsU0FKUjtBQU1EOztBQUdNLFNBQVNJLFlBQVQsQ0FBc0JHLElBQXRCLEVBQW1DQyxlQUFuQyxFQUFtRTtBQUUxRTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ00sTUFBSUMsQ0FBSjtBQUNBRixFQUFBQSxJQUFJLEdBQUdHLE1BQU0sQ0FBQ0gsSUFBRCxDQUFiO0FBQ0FuQixFQUFBQSxZQUFZLENBQUN1QixTQUFiLEdBQXlCLENBQXpCOztBQUNBLE1BQUl2QixZQUFZLENBQUN3QixJQUFiLENBQWtCTCxJQUFsQixDQUFKLEVBQTZCO0FBQ3pCQSxJQUFBQSxJQUFJLEdBQUdBLElBQUksQ0FBQ00sT0FBTCxDQUFhekIsWUFBYixFQUEyQixVQUFVMEIsQ0FBVixFQUFhO0FBQzNDLGFBQ0ksUUFDRSxDQUFDLFNBQVNBLENBQUMsQ0FBQ0MsVUFBRixDQUFhLENBQWIsRUFBZ0JqQixRQUFoQixDQUF5QixFQUF6QixDQUFWLEVBQXdDa0IsS0FBeEMsQ0FBOEMsQ0FBQyxDQUEvQyxDQUZOO0FBSUgsS0FMTSxDQUFQO0FBTUgsR0FsQm1FLENBb0IxRTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDTSxNQUNJaEMsTUFBTSxDQUFDNEIsSUFBUCxDQUNJTCxJQUFJLENBQ0NNLE9BREwsQ0FDYTVCLE1BRGIsRUFDcUIsR0FEckIsRUFFSzRCLE9BRkwsQ0FFYTNCLFFBRmIsRUFFdUIsR0FGdkIsRUFHSzJCLE9BSEwsQ0FHYTFCLE9BSGIsRUFHc0IsRUFIdEIsQ0FESixDQURKLEVBT0U7QUFDUjtBQUNBO0FBQ0E7QUFDQTtBQUVVc0IsSUFBQUEsQ0FBQyxHQUFHUSxJQUFJLENBQUMsTUFBTVYsSUFBTixHQUFhLEdBQWQsQ0FBUixDQU5GLENBUVI7QUFDQTs7QUFDVUMsSUFBQUEsZUFBZSxDQUFDQyxDQUFELENBQWY7QUFDQSxXQUFPLElBQVA7QUFDSCxHQW5EbUUsQ0FxRDFFOzs7QUFDTSxTQUFPLEtBQVA7QUFDSDs7QUFBQSIsInNvdXJjZXNDb250ZW50IjpbInZhciByeF9vbmUgPSAvXltcXF0sOnt9XFxzXSokLztcbnZhciByeF90d28gPSAvXFxcXCg/OltcIlxcXFxcXC9iZm5ydF18dVswLTlhLWZBLUZdezR9KS9nO1xudmFyIHJ4X3RocmVlID0gL1wiW15cIlxcXFxcXG5cXHJdKlwifHRydWV8ZmFsc2V8bnVsbHwtP1xcZCsoPzpcXC5cXGQqKT8oPzpbZUVdWytcXC1dP1xcZCspPy9nO1xudmFyIHJ4X2ZvdXIgPSAvKD86Xnw6fCwpKD86XFxzKlxcWykrL2c7XG52YXIgcnhfZGFuZ2Vyb3VzID0gL1tcXHUwMDAwXFx1MDBhZFxcdTA2MDAtXFx1MDYwNFxcdTA3MGZcXHUxN2I0XFx1MTdiNVxcdTIwMGMtXFx1MjAwZlxcdTIwMjgtXFx1MjAyZlxcdTIwNjAtXFx1MjA2ZlxcdWZlZmZcXHVmZmYwLVxcdWZmZmZdL2c7XG5cblxuZXhwb3J0IGZ1bmN0aW9uIENvcHlPYmplY3Qob2JqOmFueSl7XG4gIHJldHVybiBKU09OLnBhcnNlKEpTT04uc3RyaW5naWZ5KG9iaikpXG59XG5cblxuZXhwb3J0IGZ1bmN0aW9uIFZhbFRvU3RyaW5nKHZhbDphbnkpOnN0cmluZ3tcbiAgdmFyIHJldHZhbDpzdHJpbmd8dW5kZWZpbmVkID0gdW5kZWZpbmVkO1xuICBzd2l0Y2ggKHR5cGVvZih2YWwpKXtcbiAgICBjYXNlIFwic3RyaW5nXCI6XG4gICAgICByZXR2YWw9dmFsXG4gICAgICBicmVhaztcbiAgICBjYXNlIFwiYm9vbGVhblwiOlxuICAgICAgcmV0dmFsPSB2YWwudG9TdHJpbmcoKVxuICAgICAgYnJlYWs7XG4gICAgY2FzZSBcIm51bWJlclwiOlxuICAgICAgcmV0dmFsPSB2YWwudG9TdHJpbmcoKVxuICAgICAgYnJlYWs7XG4gICAgY2FzZSBcIm9iamVjdFwiOlxuICAgICAgaWYgKHZhbClcbiAgICAgICAgcmV0dmFsPUpTT04uc3RyaW5naWZ5KHZhbClcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgXCJ1bmRlZmluZWRcIjpcbiAgICAgIHJldHZhbD1cIlVuZGVmaW5lZFwiXG4gICAgICBicmVhaztcbiAgfVxuICByZXR1cm4gcmV0dmFsP3JldHZhbDpcInVuZGVmaW5lZFwiXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBTdHJpbmdUb1ZhbCh2YWxTdHJpbmc6c3RyaW5nKTpzdHJpbmd8Ym9vbGVhbnxudW1iZXJ8YW55W118b2JqZWN0e1xuICB2YXIgcGFyc2Vkb2JqZWN0OmFueTtcbiAgdmFyIHNldFBPID0gKFBPOmFueSk9PnBhcnNlZG9iamVjdD1QTztcbiAgcmV0dXJuIGlzSlNPTlN0cmluZyh2YWxTdHJpbmcsc2V0UE8pPyBwYXJzZWRvYmplY3QhIDpcbiAgICAgICAgICAhaXNOYU4odmFsU3RyaW5nKT8gTnVtYmVyKHZhbFN0cmluZykgOlxuICAgICAgICAgIHZhbFN0cmluZyA9PT0gJ3RydWUnID8gdHJ1ZSA6XG4gICAgICAgICAgdmFsU3RyaW5nID09PSAnZmFsc2UnID8gZmFsc2UgOlxuICAgICAgICAgIHZhbFN0cmluZztcblxufVxuXG5cbmV4cG9ydCBmdW5jdGlvbiBpc0pTT05TdHJpbmcodGV4dDpzdHJpbmcsIHNldFBhcnNlZE9iamVjdDooUE86YW55KT0+dm9pZCkge1xuXG4vLyBUaGUgcGFyc2UgbWV0aG9kIHRha2VzIGEgdGV4dCBhbmQgYW4gb3B0aW9uYWwgcmV2aXZlciBmdW5jdGlvbiwgYW5kIHJldHVybnNcbi8vIGEgSmF2YVNjcmlwdCB2YWx1ZSBpZiB0aGUgdGV4dCBpcyBhIHZhbGlkIEpTT04gdGV4dC5cblxuLy8gUGFyc2luZyBoYXBwZW5zIGluIGZvdXIgc3RhZ2VzLiBJbiB0aGUgZmlyc3Qgc3RhZ2UsIHdlIHJlcGxhY2UgY2VydGFpblxuLy8gVW5pY29kZSBjaGFyYWN0ZXJzIHdpdGggZXNjYXBlIHNlcXVlbmNlcy4gSmF2YVNjcmlwdCBoYW5kbGVzIG1hbnkgY2hhcmFjdGVyc1xuLy8gaW5jb3JyZWN0bHksIGVpdGhlciBzaWxlbnRseSBkZWxldGluZyB0aGVtLCBvciB0cmVhdGluZyB0aGVtIGFzIGxpbmUgZW5kaW5ncy5cbiAgICAgIHZhciBqO1xuICAgICAgdGV4dCA9IFN0cmluZyh0ZXh0KTtcbiAgICAgIHJ4X2Rhbmdlcm91cy5sYXN0SW5kZXggPSAwO1xuICAgICAgaWYgKHJ4X2Rhbmdlcm91cy50ZXN0KHRleHQpKSB7XG4gICAgICAgICAgdGV4dCA9IHRleHQucmVwbGFjZShyeF9kYW5nZXJvdXMsIGZ1bmN0aW9uIChhKSB7XG4gICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICBcIlxcXFx1XCJcbiAgICAgICAgICAgICAgICAgICsgKFwiMDAwMFwiICsgYS5jaGFyQ29kZUF0KDApLnRvU3RyaW5nKDE2KSkuc2xpY2UoLTQpXG4gICAgICAgICAgICAgICk7XG4gICAgICAgICAgfSk7XG4gICAgICB9XG5cbi8vIEluIHRoZSBzZWNvbmQgc3RhZ2UsIHdlIHJ1biB0aGUgdGV4dCBhZ2FpbnN0IHJlZ3VsYXIgZXhwcmVzc2lvbnMgdGhhdCBsb29rXG4vLyBmb3Igbm9uLUpTT04gcGF0dGVybnMuIFdlIGFyZSBlc3BlY2lhbGx5IGNvbmNlcm5lZCB3aXRoIFwiKClcIiBhbmQgXCJuZXdcIlxuLy8gYmVjYXVzZSB0aGV5IGNhbiBjYXVzZSBpbnZvY2F0aW9uLCBhbmQgXCI9XCIgYmVjYXVzZSBpdCBjYW4gY2F1c2UgbXV0YXRpb24uXG4vLyBCdXQganVzdCB0byBiZSBzYWZlLCB3ZSB3YW50IHRvIHJlamVjdCBhbGwgdW5leHBlY3RlZCBmb3Jtcy5cblxuLy8gV2Ugc3BsaXQgdGhlIHNlY29uZCBzdGFnZSBpbnRvIDQgcmVnZXhwIG9wZXJhdGlvbnMgaW4gb3JkZXIgdG8gd29yayBhcm91bmRcbi8vIGNyaXBwbGluZyBpbmVmZmljaWVuY2llcyBpbiBJRSdzIGFuZCBTYWZhcmkncyByZWdleHAgZW5naW5lcy4gRmlyc3Qgd2Vcbi8vIHJlcGxhY2UgdGhlIEpTT04gYmFja3NsYXNoIHBhaXJzIHdpdGggXCJAXCIgKGEgbm9uLUpTT04gY2hhcmFjdGVyKS4gU2Vjb25kLCB3ZVxuLy8gcmVwbGFjZSBhbGwgc2ltcGxlIHZhbHVlIHRva2VucyB3aXRoIFwiXVwiIGNoYXJhY3RlcnMuIFRoaXJkLCB3ZSBkZWxldGUgYWxsXG4vLyBvcGVuIGJyYWNrZXRzIHRoYXQgZm9sbG93IGEgY29sb24gb3IgY29tbWEgb3IgdGhhdCBiZWdpbiB0aGUgdGV4dC4gRmluYWxseSxcbi8vIHdlIGxvb2sgdG8gc2VlIHRoYXQgdGhlIHJlbWFpbmluZyBjaGFyYWN0ZXJzIGFyZSBvbmx5IHdoaXRlc3BhY2Ugb3IgXCJdXCIgb3Jcbi8vIFwiLFwiIG9yIFwiOlwiIG9yIFwie1wiIG9yIFwifVwiLiBJZiB0aGF0IGlzIHNvLCB0aGVuIHRoZSB0ZXh0IGlzIHNhZmUgZm9yIGV2YWwuXG4gICAgICBpZiAoXG4gICAgICAgICAgcnhfb25lLnRlc3QoXG4gICAgICAgICAgICAgIHRleHRcbiAgICAgICAgICAgICAgICAgIC5yZXBsYWNlKHJ4X3R3bywgXCJAXCIpXG4gICAgICAgICAgICAgICAgICAucmVwbGFjZShyeF90aHJlZSwgXCJdXCIpXG4gICAgICAgICAgICAgICAgICAucmVwbGFjZShyeF9mb3VyLCBcIlwiKVxuICAgICAgICAgIClcbiAgICAgICkge1xuLy8gSW4gdGhlIHRoaXJkIHN0YWdlIHdlIHVzZSB0aGUgZXZhbCBmdW5jdGlvbiB0byBjb21waWxlIHRoZSB0ZXh0IGludG8gYVxuLy8gSmF2YVNjcmlwdCBzdHJ1Y3R1cmUuIFRoZSBcIntcIiBvcGVyYXRvciBpcyBzdWJqZWN0IHRvIGEgc3ludGFjdGljIGFtYmlndWl0eVxuLy8gaW4gSmF2YVNjcmlwdDogaXQgY2FuIGJlZ2luIGEgYmxvY2sgb3IgYW4gb2JqZWN0IGxpdGVyYWwuIFdlIHdyYXAgdGhlIHRleHRcbi8vIGluIHBhcmVucyB0byBlbGltaW5hdGUgdGhlIGFtYmlndWl0eS5cblxuICAgICAgICAgIGogPSBldmFsKFwiKFwiICsgdGV4dCArIFwiKVwiKTtcblxuLy8gSW4gdGhlIG9wdGlvbmFsIGZvdXJ0aCBzdGFnZSwgd2UgcmVjdXJzaXZlbHkgd2FsayB0aGUgbmV3IHN0cnVjdHVyZSwgcGFzc2luZ1xuLy8gZWFjaCBuYW1lL3ZhbHVlIHBhaXIgdG8gYSByZXZpdmVyIGZ1bmN0aW9uIGZvciBwb3NzaWJsZSB0cmFuc2Zvcm1hdGlvbi5cbiAgICAgICAgICBzZXRQYXJzZWRPYmplY3Qoaik7XG4gICAgICAgICAgcmV0dXJuIHRydWVcbiAgICAgIH1cblxuLy8gSWYgdGhlIHRleHQgaXMgbm90IEpTT04gcGFyc2VhYmxlLCB0aGVuIGEgU3ludGF4RXJyb3IgaXMgdGhyb3duLlxuICAgICAgcmV0dXJuIGZhbHNlXG4gIH07Il19